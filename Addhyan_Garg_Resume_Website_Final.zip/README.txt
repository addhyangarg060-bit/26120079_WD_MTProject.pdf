ADDHYAN GARG — RESUME / PORTFOLIO WEBSITE

Files
- index.html: website content and page structure
- style.css: colours, typography, layout, spacing and responsive styling

How to preview
1. Extract this ZIP folder.
2. Open the folder in VS Code.
3. Open index.html in a browser, or use the VS Code Live Server extension.
4. Keep index.html and style.css in the same folder.

Before submitting
- Check the website and email link.
- Add any real achievements, projects, previous education or social links you want to show. Do not add information that is not accurate.
- The site currently uses a text-based AG monogram instead of a profile photo. Your profile includes Ghaziabad as your location, DPS Raj Nagar Extension as school, IIMB roll number 26120079, and the contact details you supplied. The visual palette includes navy, blue, teal and coral accents.
- The Google Fonts import needs an internet connection; fallback fonts are included.

GitHub Pages
1. Create a GitHub repository (or use the repository required by your instructor).
2. Upload index.html and style.css to the repository's root folder.
3. Commit the files.
4. In the repository, open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish. Copy the live URL shown in Settings > Pages.

Assignment PDF
Include your live website URL, repository URL, brief improvements, section explanations and design decisions in one PDF. Do not submit this ZIP as the assignment PDF.
